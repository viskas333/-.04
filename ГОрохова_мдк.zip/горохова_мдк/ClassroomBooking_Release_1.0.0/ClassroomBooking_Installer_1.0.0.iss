; Сценарий сборки установщика для Classroom Booking 1.0.0

#define MyAppName "Classroom Booking"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Кимяев"
#define MyAppExeName "ClassroomBooking.exe"

; Точные пути для пользователя afeaa
#define ProjectReleaseDir "C:\Users\afeaa\Desktop\Кимяев_мдк\ClassroomBooking\ClassroomBooking\bin\Release"
#define ReleaseOutputDir "C:\Users\afeaa\Desktop\Кимяев_мдк\ClassroomBooking_Release_1.0.0"

[Setup]
AppId={{8F4B2C1A-9D3E-4A7B-B6C5-1E2F3A4B5C6D}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\ClassroomBooking
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
PrivilegesRequired=admin
OutputDir={#ReleaseOutputDir}
OutputBaseFilename=ClassroomBooking_Setup_1.0.0
Compression=lzma
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "{#ProjectReleaseDir}\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#ProjectReleaseDir}\ClassroomBooking.exe.config"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#ProjectReleaseDir}\appsettings.json"; DestDir: "{app}"; Flags: ignoreversion

; Если в bin\Release есть сторонние DLL-библиотеки, убери точку с запятой (;) в начале следующей строки:
; Source: "{#ProjectReleaseDir}\*.dll"; DestDir: "{app}"; Flags: ignoreversion

Source: "{#ReleaseOutputDir}\README.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#ReleaseOutputDir}\RELEASE_NOTES.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
