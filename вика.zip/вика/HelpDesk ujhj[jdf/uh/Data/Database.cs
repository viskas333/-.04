﻿namespace HelpDesk_иванов.Data
{
    public class Database
    {

    }
}
