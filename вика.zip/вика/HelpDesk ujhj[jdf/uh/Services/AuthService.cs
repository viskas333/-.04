﻿namespace HelpDesk_иванов.Services
{
    public class AuthService
    {

    }
}
